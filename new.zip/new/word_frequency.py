# Из файла CSV выбираем 5 буквенные слова (1 - столбец),
# Часть речи (2 - столбец), частотность (3 - столбец) сколько раз встречается на миллион
# запись в словарь слово: частотность * 10
import sys, os
import csv


input_file = os.path.join(sys.path[0], 'freqrnc.csv')  # Файл ввода

words = dict()

with open(input_file, 'r', newline='') as csvfile:
    spamreader = csv.reader(csvfile, delimiter=' ', quotechar='|')
    for s in spamreader:
        li = s[0].split('\t')
        if len(li[0]) == 5:
            words[li[0]] = int(float(li[2]) * 10)

words = sorted(words.items(), key=lambda x: x[1], reverse=True)


i = 1
for w, f in words:
    print(i, w, f)
    i += 1